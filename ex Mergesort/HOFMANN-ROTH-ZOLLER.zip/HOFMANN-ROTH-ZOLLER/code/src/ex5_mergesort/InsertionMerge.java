package ex5_mergesort;

public interface InsertionMerge {
    void insertionMerge(int[] array);
}
